from django.contrib import admin
from .models import Userregistration
# Register your models here.

admin.site.register(Userregistration)
